Server/Client impl written by Javier Palomares and Matt Molter.
To run server first compile then run:

1. javac Server.java
2. java Server <tcp_port> <udp_port> <inventory_file_path>

To run client compile then run:
1. javac Client.java
2. java Client <server_ip> <tcp_port> <udp_port>
